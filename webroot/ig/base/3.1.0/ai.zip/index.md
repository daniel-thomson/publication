# Home - HL7® FHIR® New Zealand Base Implementation Guide v3.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org.nz/ig/base/ImplementationGuide/fhir.org.nz.ig.base | *Version*:3.1.0 |
| Active as of 2026-07-24 | *Computable Name*:HL7FHIRNewZealandBaseImplementationGuide |

### New Zealand base FHIR Implementation Guide

This is the base FHIR Implementation Guide (IG) for New Zealand. It provides a common set of reusable FHIR artifacts for representing New Zealand concepts, including extensions, identifiers, terminology artifacts, naming systems, and profiles. It is intended to support consistency across New Zealand FHIR implementations by defining shared artifacts that can be reused across implementation guides, APIs, and solutions.

The NZ Base IG is maintained as a living artifact and is expected to evolve based on feedback and usage experience from the implementation community. Concepts are included where there is a clear New Zealand-specific requirement, where reuse across implementations is expected, and where the artifact is appropriate for inclusion in a national base guide. Where suitable definitions already exist in the core FHIR specification, international implementation guides, or other recognised registries, reuse is preferred over defining new New Zealand-specific artifacts.

NZ Base is not intended to define the complete conformance requirements for a particular implementation or use case. It does not, by itself, specify which resources, profiles, extensions, terminology bindings, or interactions must be supported by an implementation. While NZ Base artifacts may define constraints, terminology, or other rules for the artifacts themselves, downstream implementation guides, programme specifications, API specifications, or other implementation-specific artifacts are expected to define which NZ Base artifacts are required, optional, or not applicable in context.

#### Macron support for Te reo Māori

By default, FHIR supports macrons (and all diacritics) as commonly used by Te Reo Māori to indicate long vowels.

Macrons are supported as FHIR uses UTF-8 for all encoding formats (JSON, XML, and RDF), and macrons are explicitly allowed by the relevant FHIR datatypes where macrons could appear.

### Overview of IG Sections

The following tabs are available from the navbar at the top.

#### Extensions

This tab lists all the extensions defined in this guide, where an extension is an additional element that can be recorded in a resource. The extension definition describes the purpose of the extension, its name and [dataType/s](https://hl7.org/fhir/R4/datatypes.html).

Clicking on the link in the 'id' column will display the detail page for that extension. Extensions can have a single value, or can be composed of multiple 'child' elements - an example is the [funded programme](StructureDefinition-funded-programme.md) extension. The snapshot tab in the details page (about halfway down) lists all the parts of the extension - including a link to the ValueSet if the element is coded.

#### Terminology

This tab lists the terminology artifacts defined in this guide. There are 2 artifacts that will be found here:

* [ValueSets](https://hl7.org/fhir/R4/valueset.html) are sets of codes, drawn from one or more code systems, intended for use in coded data elements in Resources, as defined by a particular conformance rule - such as an Extension or Profile. The ValueSets in this Guide are 'recommended' values, but it may be possible for implementers to use additional concepts if the rules defined by a particular Extension or Profile permit this.
* [CodeSystem](https://hl7.org/fhir/R4/codesystem.html) resources are used to declare the existence of and describe a code system, its key properties, and optionally define a part or all of its content. Wherever possible, the use of international terminologies, such as [SNOMED CT](https://www.snomed.org/), is recommended; however, a number of New Zealand-specific code systems are included in this Guide to meet unique, local requirements.

These resources can be used by Terminology Servers (like [Terminz](https://terminz-itp.azurewebsites.net/) or [Ontoserver](https://aehrc.com/ontoserver/) ) to provide terminology [operations](https://hl7.org/fhir/R4/operations.html) of use to implementers, such as the ValueSet [$expand](https://hl7.org/fhir/R4/valueset-operation-expand.html) operation.

There is a lot more detail on terminology in the [FHIR specification](https://hl7.org/fhir/R4/terminology-module.html). The section on [Terminology Services](https://hl7.org/fhir/R4/terminology-service.html) is also useful.

#### Identifiers

Identifiers are used to unambiguously identify something. Examples in New Zealand are the NHI (National Health Identifier) or HPI (Health Practitioner index). Each type of identifier has a url that uniquely identifies it - for example the value for the NHI is https://standards.digital.health.nz/ns/nhi-id. This url will be present in the 'system' value in a resource instance. Note that the url will not necessarily 'resolve' - entering it into a web browser will not result in anything.

#### Artifact Index

This is a tab automatically generated during the build of the Implementation Guide, and lists all the FHIR artifacts defined by the guide with a link to the details.

#### Support

Contains links to the main FHIR specification, as well downloads for the full IG or the artifacts defined in the guide (Extension Definitions, ValueSets and CodeSystems.)

If you would like to provide any feedback on this Implementation Guide, email admin@hl7.org.nz

### Version

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (fhir.org.nz.ig.base.r4)](package.r4.tgz) and [R4B (fhir.org.nz.ig.base.r4b)](package.r4b.tgz) are available.

### Dependencies



### IP Statement

This publication includes IP covered under the following statements.

* © 2020+ New Zealand Crown Copyright

* [NZ DHB](CodeSystem-dhb-code.md): [DHB](ValueSet-dhb.md), [Dhb](StructureDefinition-dhb.md), [Patient/patient-address-building-name](Patient-patient-address-building-name.md), [Patient/patient-address-suburb](Patient-patient-address-suburb.md) and [Patient/patient-dhb](Patient-patient-dhb.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [Condition/condition-long-term-condition](Condition-condition-long-term-condition.md), [Iwi_code](CodeSystem-iwi-code.md)... Show 4 more, [MedicationRequest/medicationrequest-nzeps-long-term-medication](MedicationRequest-medicationrequest-nzeps-long-term-medication.md), [MedicationRequest/medicationrequest-nzeps-supply-period-reason](MedicationRequest-medicationrequest-nzeps-supply-period-reason.md), [MedicationRequest/medicationrequest-nzeps-unusual-dose-quantity](MedicationRequest-medicationrequest-nzeps-unusual-dose-quantity.md) and [NZ_ethnic_group_codes](CodeSystem-Ethnicity.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [SubscriberPolicyholder Relationship Codes](http://terminology.hl7.org/7.2.0/CodeSystem-subscriber-relationship.html): [Coverage/CoverageCSC](Coverage-CoverageCSC.md), [Coverage/CoverageGMS](Coverage-CoverageGMS.md) and [Coverage/CoverageHUHC](Coverage-CoverageHUHC.md)
* [identifierType](http://terminology.hl7.org/7.2.0/CodeSystem-v2-0203.html): [HPIFacility](NamingSystem-hpi-facility-id.md), [HPIOrganization](NamingSystem-hpi-organisation-id.md)... Show 21 more, [HPIProvider](NamingSystem-hpi-person-id.md), [Moe_facility_id](NamingSystem-moe-facility-id.md), [NBN](NamingSystem-hpi-nzbn.md), [NZChiro](NamingSystem-chiropractic-board-id.md), [NZDental](NamingSystem-dental-council-id.md), [NZDiet](NamingSystem-dietitians-board-id.md), [NZMC](NamingSystem-medical-council-id.md), [NZMidwife](NamingSystem-midwifery-council-id.md), [NZNC](NamingSystem-nursing-council-id.md), [NZOCC](NamingSystem-occupational-therapy-board-id.md), [NZOpt](NamingSystem-optometrists-dispensing-opticians-board-id.md), [NZOst](NamingSystem-osteopathic-council-id.md), [NZParamed](NamingSystem-paramedic-council-id.md), [NZPhysio](NamingSystem-physiotherapy-board-id.md), [NZPsych](NamingSystem-psychologists-board-id.md), [NZPsycho](NamingSystem-psychotherapists-board-id.md), [NZRadiologist](NamingSystem-medical-radiation-technologists-board-id.md), [NZScience](NamingSystem-medical-sciences-council-id.md), [Nz_address_id](NamingSystem-nz-address-id.md), [Pharmacy_council_id](NamingSystem-pharmacy-council-id.md) and [Rheumatic_fever_ccs_id](NamingSystem-rheumatic-fever-ccs-id.md)
* [degreeLicenseCertificate](http://terminology.hl7.org/7.2.0/CodeSystem-v2-0360.html): [Practitioner/practitioner-additional-authorisation](Practitioner-practitioner-additional-authorisation.md), [Practitioner/practitioner-condition-on-practice](Practitioner-practitioner-condition-on-practice.md)... Show 4 more, [Practitioner/practitioner-educational-qualification](Practitioner-practitioner-educational-qualification.md), [Practitioner/practitioner-registration-initial-date](Practitioner-practitioner-registration-initial-date.md), [Practitioner/practitioner-registration-status-code](Practitioner-practitioner-registration-status-code.md) and [Practitioner/practitioner-scope-of-practice](Practitioner-practitioner-scope-of-practice.md)


### Globals

*There are no Global profiles defined*

