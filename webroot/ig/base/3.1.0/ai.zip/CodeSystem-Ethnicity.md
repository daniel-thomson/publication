# NZ ethnic group codes - HL7® FHIR® New Zealand Base Implementation Guide v3.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NZ ethnic group codes**

## CodeSystem: NZ ethnic group codes 

| | |
| :--- | :--- |
| *Official URL*:https://standards.digital.health.nz/ns/nz-ethnic-group-codes | *Version*:2.1.0 |
| Active as of 2026-07-24 | *Computable Name*:NZ_ethnic_group_codes |

 
Ethnicity New Zealand Standard Classification 2005. Ethnicity is the ethnic group or groups that people identify with or feel they belong to. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Ethnicityfull](ValueSet-Ethnicityfull.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "Ethnicity",
  "meta" : {
    "versionId" : "10",
    "lastUpdated" : "2026-06-26T15:27:24.365+12:00",
    "tag" : [{
      "system" : "https://standards.digital.health.nz/ns/nzhts-usage-tags",
      "code" : "NZBase"
    }]
  },
  "url" : "https://standards.digital.health.nz/ns/nz-ethnic-group-codes",
  "version" : "2.1.0",
  "name" : "NZ_ethnic_group_codes",
  "title" : "NZ ethnic group codes",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-24T15:52:23+12:00",
  "publisher" : "HL7 New Zealand",
  "contact" : [{
    "name" : "HL7 New Zealand",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:admin@hl7.org.nz"
    }]
  }],
  "description" : "Ethnicity New Zealand Standard Classification 2005. Ethnicity is the ethnic group or groups that people identify with or feel they belong to.",
  "caseSensitive" : true,
  "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/nz-ethnic-group-code",
  "versionNeeded" : false,
  "content" : "complete",
  "count" : 262,
  "property" : [{
    "code" : "parent",
    "uri" : "http://hl7.org/fhir/concept-properties#parent",
    "description" : "The concept identified in this property is a parent of the concept on which it is used",
    "type" : "code"
  }],
  "concept" : [{
    "code" : "96666",
    "display" : "Repeated Value",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Repeated Value"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "966"
    }]
  },
  {
    "code" : "351",
    "display" : "Tokelauan",
    "property" : [{
      "code" : "parent",
      "valueCode" : "35"
    }]
  },
  {
    "code" : "111",
    "display" : "New Zealand European",
    "property" : [{
      "code" : "parent",
      "valueCode" : "11"
    }]
  },
  {
    "code" : "31111",
    "display" : "Samoan",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "W Samoa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Samoan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Samoan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "American Samoan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Born Samoan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Samoan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Born Samoan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Western Samoa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Samoa"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "311"
    }]
  },
  {
    "code" : "12950",
    "display" : "Zimbabwean European",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Zimbabwean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White Zimbabwean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zimbabwean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zimbabwe"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zimbabwean European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zimbabwe European"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12711",
    "display" : "German",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Badisch"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sachsen"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "German"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Swabian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Deutsch"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tiamana"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Prussian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "German European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "East German"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "West German"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bavarian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European German"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Teutonic"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Germany"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "127"
    }]
  },
  {
    "code" : "10",
    "display" : "European nfd",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1"
    }]
  },
  {
    "code" : "11",
    "display" : "New Zealand European",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1"
    }]
  },
  {
    "code" : "42112",
    "display" : "Cambodian Chinese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chinese Cambodian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cambodian Chinese"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "421"
    }]
  },
  {
    "code" : "44412",
    "display" : "Bangladeshi",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bangladesh"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bangladeshi"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "444"
    }]
  },
  {
    "code" : "12",
    "display" : "Other European",
    "property" : [{
      "code" : "parent",
      "valueCode" : "1"
    }]
  },
  {
    "code" : "42113",
    "display" : "Malaysian Chinese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malaysian Chinese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chinese Malaysian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malaysia Chinese"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "421"
    }]
  },
  {
    "code" : "44411",
    "display" : "Afghan",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pashto"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pushtu"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Afghanistan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Afgani"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hazara"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pushtoo"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Afghani"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Afghan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Afgan"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "444"
    }]
  },
  {
    "code" : "42114",
    "display" : "Singaporean Chinese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Singapore Chinese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Singaporean Chinese"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "421"
    }]
  },
  {
    "code" : "44414",
    "display" : "Pakistani",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Muslim Pakistan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pakistan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pakastani"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pakistani"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "444"
    }]
  },
  {
    "code" : "42115",
    "display" : "Vietnamese Chinese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Vietnam Chinese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Vietnamese Chinese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chinese Vietnamese"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "421"
    }]
  },
  {
    "code" : "44413",
    "display" : "Nepali",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Lhotshampa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nepali"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nepalese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nepal"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "444"
    }]
  },
  {
    "code" : "42111",
    "display" : "Hong Kong Chinese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hong Kong"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hong Kong Chinese"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "421"
    }]
  },
  {
    "code" : "36111",
    "display" : "Fijian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Fiji"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Fijian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Fijian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Fiji Islands"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Fijian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Whiti"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Fiji Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "iTaukei"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "361"
    }]
  },
  {
    "code" : "44419",
    "display" : "Mongolian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mongolian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "444"
    }]
  },
  {
    "code" : "42116",
    "display" : "Taiwanese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Taiwanese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Taiwan Roc"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Taiwaness"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Taiwan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Taiwanese Chinese"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "421"
    }]
  },
  {
    "code" : "44416",
    "display" : "Eurasian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Amerasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Euro Asian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Urasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Indo"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Eurasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Euroasian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "444"
    }]
  },
  {
    "code" : "44415",
    "display" : "Tibetan",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tibetan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Khampa"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "444"
    }]
  },
  {
    "code" : "361",
    "display" : "Fijian",
    "property" : [{
      "code" : "parent",
      "valueCode" : "36"
    }]
  },
  {
    "code" : "44418",
    "display" : "Maldivian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Maldives"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Maldivian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "444"
    }]
  },
  {
    "code" : "44417",
    "display" : "Bhutanese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bhutanese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bhutan"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "444"
    }]
  },
  {
    "code" : "121",
    "display" : "British and Irish",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    }]
  },
  {
    "code" : "1",
    "display" : "European"
  },
  {
    "code" : "122",
    "display" : "Dutch",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    }]
  },
  {
    "code" : "123",
    "display" : "Greek",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    }]
  },
  {
    "code" : "2",
    "display" : "Māori"
  },
  {
    "code" : "124",
    "display" : "Polish",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    }]
  },
  {
    "code" : "3",
    "display" : "Pacific Peoples"
  },
  {
    "code" : "125",
    "display" : "South Slav",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    }]
  },
  {
    "code" : "4",
    "display" : "Asian"
  },
  {
    "code" : "126",
    "display" : "Italian",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    }]
  },
  {
    "code" : "5",
    "display" : "Middle Eastern/Latin American/African"
  },
  {
    "code" : "127",
    "display" : "German",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    }]
  },
  {
    "code" : "6",
    "display" : "Other Ethnicity"
  },
  {
    "code" : "128",
    "display" : "Australian",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    }]
  },
  {
    "code" : "129",
    "display" : "Other European",
    "property" : [{
      "code" : "parent",
      "valueCode" : "12"
    }]
  },
  {
    "code" : "9",
    "display" : "Residual Categories"
  },
  {
    "code" : "21",
    "display" : "Māori",
    "property" : [{
      "code" : "parent",
      "valueCode" : "2"
    }]
  },
  {
    "code" : "41499",
    "display" : "Southeast Asian nec",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kachin"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Southeast Asian Nec"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Singapore"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Singaporean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Iban"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kayah"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Shan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sinaporean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hmong"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dayak"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "East Timorese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Melanau"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mon"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Karenni"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Brunei"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cham"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Rohingya"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sarawak"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zomi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kadazan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Timorese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kayan"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "414"
    }]
  },
  {
    "code" : "97777",
    "display" : "Response Unidentifiable",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Antipodean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Cross"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "other"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Indigenous"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "DK"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mixed Origin"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Non NZ European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mixed Descent"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "SA"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mixture"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mixed Race"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Native"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Everything"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Other Group"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Half Blooded"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Other Unknown"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "UN"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Many"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Aus"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "UNZ"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Others"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Non New Zealand European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "OS"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Multiracial"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mixed Blood"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hybrid"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tahi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Antillan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Aust"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Non European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Multi Cultural"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Response Unidentifiable"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Austraian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Unidentifiable"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mediterranean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "DKZ"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Aust European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British Colonial"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NSZ"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mixed"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "OSZ"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Multicultural"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mixed Ancestry"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Unknown Adopted"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "977"
    }]
  },
  {
    "code" : "42100",
    "display" : "Chinese nfd",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sino"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Chinese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "China"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chinese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Born Chinese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mandarin"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Born Chinese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chinese Nfd"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Chinese"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "421"
    }]
  },
  {
    "code" : "371",
    "display" : "Other Pacific Peoples",
    "property" : [{
      "code" : "parent",
      "valueCode" : "37"
    }]
  },
  {
    "code" : "12935",
    "display" : "Russian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White Russian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Russian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Russian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Soviet"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Russian European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Russia"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12933",
    "display" : "Romanian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Romania"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Romanian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Rumanian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Vlach"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12934",
    "display" : "Romani",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Romani"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Romany"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Romany Gypsy"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Gypsy"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Romine"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Romani Gypsy"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12939",
    "display" : "Spanish",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Spaniard"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Spanish European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Iberian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Catalan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Spanish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Paniora"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Galician"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Spanish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Castillian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Spain"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Espanol"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12937",
    "display" : "Slavic",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Slav"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Slavic"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "30000",
    "display" : "Pacific Peoples nfd",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "French Polynesian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pacific Island"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White Pacific Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pacific Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pacific"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pacific Peoples nfd"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South Pacific Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Melanesian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Polynesian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Micronesian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "300"
    }]
  },
  {
    "code" : "52199",
    "display" : "Latin American nec",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "El Salvadorean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Costa Rican"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Panamanian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malvinian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dominican"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Guyanese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Latin American Nec"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Guatemalan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nicaraguan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Honduran"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Latin American Creole"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Belizean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Paraguayan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cuban"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Surinamese"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "521"
    }]
  },
  {
    "code" : "12938",
    "display" : "Slovak",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Slovak"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Slovakian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Carpathian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12931",
    "display" : "Norwegian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Viking"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Norway"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nordic"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Norse"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Norwegian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12811",
    "display" : "Australian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Australian White"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Aussie"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Australian European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Australia European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Austrauan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Auzzie"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Austrlian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Australia"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Austalian European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White Australian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Australian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Naturalised Australian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Australian Caucasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Anglo Australian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ozzie"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Australian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Australia"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tasmanian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "128"
    }]
  },
  {
    "code" : "12932",
    "display" : "Portuguese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Portuguese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Portugese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Portugal"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "30",
    "display" : "Pacific Peoples nfd",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3"
    }]
  },
  {
    "code" : "31",
    "display" : "Samoan",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3"
    }]
  },
  {
    "code" : "12930",
    "display" : "Maltese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Maltese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malta"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "32",
    "display" : "Cook Islands Maori",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3"
    }]
  },
  {
    "code" : "33",
    "display" : "Tongan",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3"
    }]
  },
  {
    "code" : "41000",
    "display" : "Southeast Asian nfd",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Southeast Asian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South East Asian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South East Asia"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Southeast Asian Nfd"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "SE Asian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "410"
    }]
  },
  {
    "code" : "34",
    "display" : "Niuean",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3"
    }]
  },
  {
    "code" : "35",
    "display" : "Tokelauan",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3"
    }]
  },
  {
    "code" : "36",
    "display" : "Fijian",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3"
    }]
  },
  {
    "code" : "37",
    "display" : "Other Pacific Peoples",
    "property" : [{
      "code" : "parent",
      "valueCode" : "3"
    }]
  },
  {
    "code" : "44199",
    "display" : "Sri Lankan nec",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sri Lankan Nec"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "441"
    }]
  },
  {
    "code" : "12947",
    "display" : "New Caledonian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Caledonian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "61118",
    "display" : "New Zealander",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand National"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Kiwi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Aucklander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Indigenous New Zealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nen Zealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mainland New Zealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Aotearoan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "100% Kiwi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Mix"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Non European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ngai South Island"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South Islander New Zealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "West Coaster"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Native Kiwi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Newzealand"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Native New Zealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White Native New Zealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Non Maori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Aotearoa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Naturalised New Zealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZder"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Kiwi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zealand"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealander of British Descent"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealander Non Maori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealander of Irish Descent"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White Kiwi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kiw"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kiwi New Zealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealander Not NZ European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Im A New Zealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Native"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealander Born And Bred"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Caucasian New Zealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZlander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European New Zealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealander and Proud of it"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cantabrian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mainlander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealander Non European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Im A Kiwi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZer"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Person"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Niu Tireni"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealander Only"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zelander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White New Zealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Kiwi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Newzealander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South Island NZ Descent"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chatham Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kiwi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealanders"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealander Not European"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "611"
    }]
  },
  {
    "code" : "12945",
    "display" : "Canadian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kanuck"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Canadian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Quebecois"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Canadian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cdn"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "French Canadian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Canada"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Canadian European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Canadian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Canadian Caucasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Caucasian Canadian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Canadian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Native Canadian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White Canadian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "61117",
    "display" : "Other South African",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South African Coloured"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cape Coloured"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Other South African"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Coloured South African"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "611"
    }]
  },
  {
    "code" : "61116",
    "display" : "Seychellois",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Seychelles Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Seychellois"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Seychelloise"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Seychelles"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "611"
    }]
  },
  {
    "code" : "61115",
    "display" : "Mauritian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mauritian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mauritius"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "611"
    }]
  },
  {
    "code" : "12948",
    "display" : "South African European",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dutch South African"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South African European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Sth African"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South African Of British Descent"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South African English"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European South Africa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British South African"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European South African"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South African White"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South African Caucasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Southafrican"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South Africa European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South Africa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "English South African"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White South African"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South African"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12949",
    "display" : "Afrikaner",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Afrikaans European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South African Afrikaner"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Afrikaner"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Boer"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Afrikaaner"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Afrikaans"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Afrikaans South African"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "61113",
    "display" : "Indigenous American",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Inca"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South American Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Inuit"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Canadian Aboriginal"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Metis"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Eskimo"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Maya Indios"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Central American Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cree"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cheyenne Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sioux Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mayan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Canadian Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Indigenous American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Native American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sioux"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mapuche"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Native North American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cherokee"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tsimpshian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Apache"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Navaho"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Blackfoot"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Quechua"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "First Nations"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Canadian Native Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cherokee Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "North American Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ojibway"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Native American Indian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "611"
    }]
  },
  {
    "code" : "944",
    "display" : "Don't Know",
    "property" : [{
      "code" : "parent",
      "valueCode" : "94"
    }]
  },
  {
    "code" : "12942",
    "display" : "Ukrainian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ukrainian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ruthenian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ukraine"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ukranian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "40",
    "display" : "Asian nfd",
    "property" : [{
      "code" : "parent",
      "valueCode" : "4"
    }]
  },
  {
    "code" : "12943",
    "display" : "American",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "United States"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "American European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "USA American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "USA White"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "North American Caucasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "American Caucasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "USA Caucasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Caucasian American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "North American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "US American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "USA European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "US Caucasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "United States Caucasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "America"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White North American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "North American European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "US"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Californian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "US European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "USA"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Yankee"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "United States Of America"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Caucasian Usa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Alaskan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Usa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White USA"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Texan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "United States European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Anglo American"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "41",
    "display" : "Southeast Asian",
    "property" : [{
      "code" : "parent",
      "valueCode" : "4"
    }]
  },
  {
    "code" : "12940",
    "display" : "Swedish",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sweden"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Svensk"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Swede"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Swedish European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Swedish"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "42",
    "display" : "Chinese",
    "property" : [{
      "code" : "parent",
      "valueCode" : "4"
    }]
  },
  {
    "code" : "12941",
    "display" : "Swiss",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Swiss European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Swiss"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Helvetian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Schweizer"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Suisse"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Swiss"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Switzerland"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "43",
    "display" : "Indian",
    "property" : [{
      "code" : "parent",
      "valueCode" : "4"
    }]
  },
  {
    "code" : "44",
    "display" : "Other Asian",
    "property" : [{
      "code" : "parent",
      "valueCode" : "4"
    }]
  },
  {
    "code" : "98888",
    "display" : "Response Outside Scope",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Jedi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "The Human Race"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NAZ"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Earthling"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Black"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "My Own"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Muslim"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Coptic"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Non Maori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "United States Citizen"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Citizen"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Racist Question"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White Man"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Wizards"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zorastrian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Australian Born"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ex south african"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hobbits"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Australian Citizen"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Human"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Universal"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Homo Sapien"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Catholic"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Spartan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Personal"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Urdu"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bitsa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Atlantan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Israeli Born"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Citizen Of The Global Village"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "All Of Them"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Homo Sapiens"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Islam"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Moslem"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dwarfs"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dual Citizenship"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White Person"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Person"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mix"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Adopted"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Buddhist"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cosmopolitan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Koran"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Naturalised"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Buddhism"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Royalty"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Resident"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Alien"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Citizen"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dual Nationality"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "American Citizen"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Space Alien"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Neanderthal"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ National"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Resident"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sovereign"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "English Speaking"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British Citizen"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "US Citizen"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "None"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Human Being"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Goblins"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Elves"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Jedi Knight"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "All Of The Above"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "English Born"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Human Race"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nothing"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British Born"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "No Ethnic Group"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Citizen Of The World"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zorashtrian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Church Of England"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Naturalised NZ"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Born"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dutch born"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "None Of The Above"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Response Outside Scope"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Arian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Not Relevant"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White Boy"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NA"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Citizenship"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Citizenship"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Individual"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Greek Orthodox"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Both"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Buddist"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Not Applicable"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Born"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "USA Citizen"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Lama"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British Subject"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "World Citizen"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Not European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "International"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "English By Birth"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Martian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Born In New Zealand"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Black Riders"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Internationalist"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Middle Earth"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nil"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Christian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zoroastrian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Born In England"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "988"
    }]
  },
  {
    "code" : "41111",
    "display" : "Filipino",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pilipino"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Filipina"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Filipino"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pilipina"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Filipino"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Philippino"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ilocano"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tagalog"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Visaya"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Phillippines"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Philipino"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Philippine"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Fillipino"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bisayan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cebuano"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Phillippine"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Asian Filipino"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Philippines"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Filipino Asian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Philipines"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Filippino"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Phillipino"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Filipino"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Philippines Filipino"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Asian Philippines"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "411"
    }]
  },
  {
    "code" : "35111",
    "display" : "Tokelauan",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tokelauan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tokelau"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tokeluan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Atafu"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Fakaofo"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tokelaun"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tokelau Island"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Fakaofo Island"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tokelau Is"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "351"
    }]
  },
  {
    "code" : "12913",
    "display" : "Austrian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Austrian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Austria"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Austrian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Austrian European"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12119",
    "display" : "Scottish",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kootimana"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Scotland"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Highlander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British Scottish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Scottish European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Scotish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Scotsman"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Scottish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Scot"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Scotch"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Koterana"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Scotland"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kotimana"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White Scottish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Scots European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Scottish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Scotts"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Scots"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "121"
    }]
  },
  {
    "code" : "12914",
    "display" : "Belgian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Belg"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Belgium"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Walloon"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Belgian European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Belgian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12911",
    "display" : "Albanian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Albanian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kosovar Albanian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12912",
    "display" : "Armenian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Armenian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12918",
    "display" : "Cypriot nfd",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cypriot"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12915",
    "display" : "Bulgarian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bulgarian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12916",
    "display" : "Belorussian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Belarussian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Belorussian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Belarusian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Belarus"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12112",
    "display" : "Channel Islander",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Guernsey Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Channel Islands"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Channel Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Jersey"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "121"
    }]
  },
  {
    "code" : "12111",
    "display" : "Celtic nfd",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Keltic"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Celtic"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Celt"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Celtic nfd"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Breton"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Anglo Celtic"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Celtic Descent"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "121"
    }]
  },
  {
    "code" : "955",
    "display" : "Refused to Answer",
    "property" : [{
      "code" : "parent",
      "valueCode" : "95"
    }]
  },
  {
    "code" : "12114",
    "display" : "English",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White European English"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British English"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "English White"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mercean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "England"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pommie"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "English British"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "English White European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Anglo Saxon"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "English Anglo Saxon"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Englishman"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Saxon"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Yorkshire"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White Anglo Saxon"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Anglosaxon"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "English European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ingarihi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "English Caucasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Wasp"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pom"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "English"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White English"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "England European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "English UK"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "London"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Anglo"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Geordie"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British England"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cockney"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "English White Caucasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European English"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "121"
    }]
  },
  {
    "code" : "12113",
    "display" : "Cornish",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cornish"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "121"
    }]
  },
  {
    "code" : "12116",
    "display" : "Irish",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Irish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Irish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Anglo Irish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Airihi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Irishman"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Northern Ireland"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Irish European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White Irish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Irish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Northern Irish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British Irish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Irish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ireland"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ulster"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Eire"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "121"
    }]
  },
  {
    "code" : "51",
    "display" : "Middle Eastern",
    "property" : [{
      "code" : "parent",
      "valueCode" : "5"
    }]
  },
  {
    "code" : "52",
    "display" : "Latin American",
    "property" : [{
      "code" : "parent",
      "valueCode" : "5"
    }]
  },
  {
    "code" : "12599",
    "display" : "South Slav nec",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kosovar"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kosova"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Montenegrin"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South Slav Nec"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "125"
    }]
  },
  {
    "code" : "53",
    "display" : "African",
    "property" : [{
      "code" : "parent",
      "valueCode" : "5"
    }]
  },
  {
    "code" : "12117",
    "display" : "Manx",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Isle Of Man"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Manx"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "121"
    }]
  },
  {
    "code" : "12121",
    "display" : "Welsh",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Welsh"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cymru"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Wales"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Welsh"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Welsh European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British Welsh"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Welsh British"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Anglo Welsh"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "121"
    }]
  },
  {
    "code" : "12919",
    "display" : "Czech",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Czech Republic"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Moravian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Czech European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bohemian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Czechoslovakian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Czech"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12924",
    "display" : "French",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "French"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European French"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "French European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Huguenot"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Part French"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Francais"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "France"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Wiwi"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "53199",
    "display" : "African nec",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Southern Sotho"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Moor"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cameroon"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pigmy"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Jula"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Swazi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kongo"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ngoni"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Rundi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South Sudanese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Angolan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zulu"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Shona"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kirundi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "SA African"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bambara"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bahima"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cajun"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Lomwe"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Twa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malagasy"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Fanti"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ashanti"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Rwandan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Swahili"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Black European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Black British"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Namibian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mosotho"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Motswana"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "African Nec"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sotho"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kon Komba"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chiga"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ndebele"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Fulani"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Yoruba"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Peul"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Black South African"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mina"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hutu"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Khoisa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Madagascan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Creole American Born"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mande"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zairean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ewe"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Creole (US)"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hottentot"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mosambique"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Black Zimbabwean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Fur"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Banda"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Xhosa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Akan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ugandan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hausa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Songhai"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Creole"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malawian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tanzanian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zarma"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zanzibarian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bantu"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tswana"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "12922",
    "display" : "Finnish",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Finn"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Finland"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Finnish"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12923",
    "display" : "Flemish",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Flemish"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12928",
    "display" : "Latvian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Latvian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12929",
    "display" : "Lithuanian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Lithuanian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12926",
    "display" : "Hungarian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Hungarian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hungary"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hungarian European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hungarian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ugrian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Magyar"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12927",
    "display" : "Icelandic",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Icelander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Icelandic"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "966",
    "display" : "Repeated Value",
    "property" : [{
      "code" : "parent",
      "valueCode" : "96"
    }]
  },
  {
    "code" : "61",
    "display" : "Other Ethnicity",
    "property" : [{
      "code" : "parent",
      "valueCode" : "6"
    }]
  },
  {
    "code" : "12920",
    "display" : "Danish",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dane"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dansk"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Denmark"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Danish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Danish European"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "12921",
    "display" : "Estonian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Estonian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "37199",
    "display" : "Pacific Peoples nec",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Irelander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Easter Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Palauan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Wallace Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Yapese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Admiralty Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Marianas Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Belau Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Wallis Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ocean Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malaitian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Marquesian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Manus Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Wake Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Marquesas Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Uvean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bismark Archipelagoan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pacific Peoples nec"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Palau Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Truk Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Phoenix Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Guadalcanalian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Britain Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Belauan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chamorro"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Banaban"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kosraen"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pohnpeian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Georgian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kusaien"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tuamotu Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Yap Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Austral Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kanak"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Norfolk Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Norfolk Island"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Marshall Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bougainvillean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Caroline Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Briton"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Guam Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Santa Cruz Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Uvea"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Futuna Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Marshallese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Gambier Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hiva Oa Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Wallisian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "371"
    }]
  },
  {
    "code" : "41211",
    "display" : "Cambodian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Campuchia"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Asian Cambodian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cambodian Asian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cambodian Khmer"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cambodia"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cambodian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kampuchean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Khmer Cambodian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Khmer"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Khmer Krom"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "412"
    }]
  },
  {
    "code" : "43199",
    "display" : "Indian nec",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kashmiri"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Telegu"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ugandan Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Gujrat"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Indian Nec"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "UK Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Keralite"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kannadiga"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bihari"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Vaisanava"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Gujarati"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Goan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malayalee"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bidayuh"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malayali"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "431"
    }]
  },
  {
    "code" : "40000",
    "display" : "Asian nfd",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Asian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Asia"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Asian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Asian Nfd"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South Asian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Other Asian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Asian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "400"
    }]
  },
  {
    "code" : "99999",
    "display" : "Not Stated",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Not Specified"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NS"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Not Stated"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "999"
    }]
  },
  {
    "code" : "51100",
    "display" : "Middle Eastern nfd",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Middle East"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Semitic"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Middle Eastern"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Middel East"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "North African"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Middle Eastern Nfd"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Semite"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Middle Eastren"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Midleast"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "611",
    "display" : "Other Ethnicity",
    "property" : [{
      "code" : "parent",
      "valueCode" : "61"
    }]
  },
  {
    "code" : "12211",
    "display" : "Dutch",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tatimana"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nederlander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dutch European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Dutch"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Dutch"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Netherlands"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dutch Netherlands"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dutch Parents"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nederland"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Dutch"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dutch"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dutch Naturalised"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Holland"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "122"
    }]
  },
  {
    "code" : "977",
    "display" : "Response Unidentifiable",
    "property" : [{
      "code" : "parent",
      "valueCode" : "97"
    }]
  },
  {
    "code" : "51111",
    "display" : "Algerian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Algerian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "51113",
    "display" : "Assyrian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Assyrian From Iraq"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Assaryan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Assyrian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Assryan"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "34111",
    "display" : "Niuean",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Niuean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Niue Island"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Niue"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "341"
    }]
  },
  {
    "code" : "51112",
    "display" : "Arab",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Saudi Arabia"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Arabic"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Saudi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Middle East Arab"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Arabian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Arab Middle East"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Arabs"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Saudi Arabian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Arab"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "51115",
    "display" : "Iranian/Persian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Persian Iranian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Parsee"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Parsi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Iran"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Farsi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Iranian Persian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Persian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Iranian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "12100",
    "display" : "British nfd",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British White"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White British"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "United Kingdom"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Britain"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European UK"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British Caucasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British Visitor"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Briton"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British Descent"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Great Britain"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "UK White"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Caucasian British"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European British"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "UK"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British Nfd"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ British"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand British"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British UK"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Brittish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British Isles"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Other European British"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "UK European"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "121"
    }]
  },
  {
    "code" : "51114",
    "display" : "Egyptian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Egyptian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Egypt"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Coptic Egyptian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "988",
    "display" : "Response Outside Scope",
    "property" : [{
      "code" : "parent",
      "valueCode" : "98"
    }]
  },
  {
    "code" : "51117",
    "display" : "Israeli/Jewish",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Israeli"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hebrew"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Khazar"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sephardic"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Jewish European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ashkenazi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Israel"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Jew"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Jewish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Israeli Jewish"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "51116",
    "display" : "Iraqi",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Khaldean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chaldean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Iraqis"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Iraqian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Iraqi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Iraq"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Babylon"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Arabic Iraqi"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "51119",
    "display" : "Kurd",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kurdistan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kurdish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kurd"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "51118",
    "display" : "Jordanian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Jordanian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Jordan"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "41311",
    "display" : "Vietnamese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Vietnam"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Viet Nam"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South Vietnamese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Vietnamese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Viet Namese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Vietmanese"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "413"
    }]
  },
  {
    "code" : "51120",
    "display" : "Lebanese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Lebanon"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Lebanese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Lebonese"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "51122",
    "display" : "Moroccan",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Morocco"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Moroccan"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "511",
    "display" : "Middle Eastern",
    "property" : [{
      "code" : "parent",
      "valueCode" : "51"
    }]
  },
  {
    "code" : "51124",
    "display" : "Palestinian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Palestinian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Palestine"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "51125",
    "display" : "Syrian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Syrian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Syria"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Syriac"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "999",
    "display" : "Not Stated",
    "property" : [{
      "code" : "parent",
      "valueCode" : "99"
    }]
  },
  {
    "code" : "12311",
    "display" : "Greek",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Greece"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cretan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Greek Cypriot"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Greek"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Greek European"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "123"
    }]
  },
  {
    "code" : "51127",
    "display" : "Turkish",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Turkey"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Turkish Cypriot"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Uygur"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Uyghur"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Turk"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Turkish"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "94",
    "display" : "Don't Know",
    "property" : [{
      "code" : "parent",
      "valueCode" : "9"
    }]
  },
  {
    "code" : "95",
    "display" : "Refused to Answer",
    "property" : [{
      "code" : "parent",
      "valueCode" : "9"
    }]
  },
  {
    "code" : "96",
    "display" : "Repeated Value",
    "property" : [{
      "code" : "parent",
      "valueCode" : "9"
    }]
  },
  {
    "code" : "97",
    "display" : "Response Unidentifiable",
    "property" : [{
      "code" : "parent",
      "valueCode" : "9"
    }]
  },
  {
    "code" : "98",
    "display" : "Response Outside Scope",
    "property" : [{
      "code" : "parent",
      "valueCode" : "9"
    }]
  },
  {
    "code" : "99",
    "display" : "Not Stated",
    "property" : [{
      "code" : "parent",
      "valueCode" : "9"
    }]
  },
  {
    "code" : "44499",
    "display" : "Asian nec",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pathan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tartar"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Uzbek"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Asian Nec"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Macanese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Buryat"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Yakut (Sakha)"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tajek"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Azeri"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kazahstani"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kazakh"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tajik"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ossetian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tatar"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Wakhi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Uzbeki"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Turkmenian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kyrgyz"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Uzbeci"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "444"
    }]
  },
  {
    "code" : "42199",
    "display" : "Chinese nec",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chou Zhou"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Han"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hokkien"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hakka"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chinese Nec"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cantonese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Fujian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "421"
    }]
  },
  {
    "code" : "400",
    "display" : "Asian nfd",
    "property" : [{
      "code" : "parent",
      "valueCode" : "40"
    }]
  },
  {
    "code" : "521",
    "display" : "Latin American",
    "property" : [{
      "code" : "parent",
      "valueCode" : "52"
    }]
  },
  {
    "code" : "52100",
    "display" : "Latin American nfd",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South America"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Central American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Latina"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Latin American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Latino"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Latin"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hispanic"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Latino American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Latin America"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Latin American Nfd"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "521"
    }]
  },
  {
    "code" : "11111",
    "display" : "New Zealand European",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pakeha"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZEuropean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ngati Pakeha"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Pakeha"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand White"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Pakeha"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand European Pakeha"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Palangi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tau Iwi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ European Pakeha"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Caucasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tauiwi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Euro"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ European/Pakeha"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "111"
    }]
  },
  {
    "code" : "41411",
    "display" : "Burmese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Anglo Burmese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Myanmar"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Burmese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Burma"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Arakanese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Rakhine"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "414"
    }]
  },
  {
    "code" : "41415",
    "display" : "Thai",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Asian Thai"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Thai"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Thai"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Siamese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Thai"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Thailand"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tai"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "414"
    }]
  },
  {
    "code" : "41414",
    "display" : "Malay",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Peranakan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malaccan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sabahan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malayan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malaysian Malay"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malaysia"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malay"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malaysian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Melayu"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "414"
    }]
  },
  {
    "code" : "41413",
    "display" : "Lao",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Asian Laos"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Laoation"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Lao"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Laosian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Laos"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Laotian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "414"
    }]
  },
  {
    "code" : "41412",
    "display" : "Indonesian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Javanese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bali"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Balinese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Indonesian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bornean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sumatran"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Indonesia"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "414"
    }]
  },
  {
    "code" : "41417",
    "display" : "Chin",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Burmese Chin"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chin"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Myanmar Chin"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "414"
    }]
  },
  {
    "code" : "41416",
    "display" : "Karen",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Burmese Karen"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ethnic Karen"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Karen"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Karen Burma"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "414"
    }]
  },
  {
    "code" : "410",
    "display" : "Southeast Asian nfd",
    "property" : [{
      "code" : "parent",
      "valueCode" : "41"
    }]
  },
  {
    "code" : "531",
    "display" : "African",
    "property" : [{
      "code" : "parent",
      "valueCode" : "53"
    }]
  },
  {
    "code" : "411",
    "display" : "Filipino",
    "property" : [{
      "code" : "parent",
      "valueCode" : "41"
    }]
  },
  {
    "code" : "52113",
    "display" : "Brazilian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Brazillian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Brazil"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Brazilian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Brasilian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "521"
    }]
  },
  {
    "code" : "412",
    "display" : "Cambodian",
    "property" : [{
      "code" : "parent",
      "valueCode" : "41"
    }]
  },
  {
    "code" : "52114",
    "display" : "Chilean",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chilean South American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chilean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chile"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "521"
    }]
  },
  {
    "code" : "413",
    "display" : "Vietnamese",
    "property" : [{
      "code" : "parent",
      "valueCode" : "41"
    }]
  },
  {
    "code" : "52111",
    "display" : "Argentinian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Argentina"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Argentinian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Argentinean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Argentine"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "521"
    }]
  },
  {
    "code" : "33111",
    "display" : "Tongan",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tongan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tonga"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "331"
    }]
  },
  {
    "code" : "414",
    "display" : "Other Southeast Asian",
    "property" : [{
      "code" : "parent",
      "valueCode" : "41"
    }]
  },
  {
    "code" : "52112",
    "display" : "Bolivian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bolivian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "521"
    }]
  },
  {
    "code" : "12411",
    "display" : "Polish",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Polish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Poland"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Polish European"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "124"
    }]
  },
  {
    "code" : "52118",
    "display" : "Ecuadorian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ecuadorian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "521"
    }]
  },
  {
    "code" : "52115",
    "display" : "Colombian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Colombia"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Colombian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "521"
    }]
  },
  {
    "code" : "37140",
    "display" : "Tahitian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tahitian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "French Tahitian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tahisian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tahiti"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Society Islander"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "371"
    }]
  },
  {
    "code" : "37141",
    "display" : "Solomon Islander",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Solomon Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Solomon"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Solomon Island"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Solomon Islands"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "371"
    }]
  },
  {
    "code" : "44111",
    "display" : "Sinhalese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sinhala"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sinhalese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Singhalese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sinhalese Sri Lankan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sri Lankan Sinhalese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sin Halese"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "441"
    }]
  },
  {
    "code" : "37144",
    "display" : "Tuvaluan",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Funafuti"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tuvalan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tuvaluan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ellice Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tuvalu Island"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tuvalu"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "371"
    }]
  },
  {
    "code" : "37145",
    "display" : "Ni Vanuatu",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ni Vanuatu"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Vanuatu"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nivan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Vanuatuan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Hebridean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Vanuatu Islander New Hebridean"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "371"
    }]
  },
  {
    "code" : "44112",
    "display" : "Sri Lankan Tamil",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ceylon Tamil"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Srilankan Tamil"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Eelam Tamil"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sri Lankan Tamil"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "441"
    }]
  },
  {
    "code" : "300",
    "display" : "Pacific Peoples nfd",
    "property" : [{
      "code" : "parent",
      "valueCode" : "30"
    }]
  },
  {
    "code" : "421",
    "display" : "Chinese",
    "property" : [{
      "code" : "parent",
      "valueCode" : "42"
    }]
  },
  {
    "code" : "52123",
    "display" : "Mexican",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mexican"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mexico"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "521"
    }]
  },
  {
    "code" : "10000",
    "display" : "European nfd",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White Caucasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "North European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Northern European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Continental European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Indo European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "White African"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Caucasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mediteranian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Nfd"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mixed European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Central European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Europe"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Australasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "East European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Baltic"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Caucasian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Eastern European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sa European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Euro"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Western European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Descent"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Caucasian European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Caucasion"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European White"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "100"
    }]
  },
  {
    "code" : "52128",
    "display" : "Puerto Rican",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Puerto Rican"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Puertorican"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "521"
    }]
  },
  {
    "code" : "52129",
    "display" : "Uruguayan",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Uruguayan"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "521"
    }]
  },
  {
    "code" : "61199",
    "display" : "Other Ethnicity nec",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "African Coloured"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Other Ethnicity Nec"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Coloured"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "611"
    }]
  },
  {
    "code" : "52127",
    "display" : "Peruvian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Peruvian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Peru"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "521"
    }]
  },
  {
    "code" : "37130",
    "display" : "Nauruan",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nauruan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nauru"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "371"
    }]
  },
  {
    "code" : "94444",
    "display" : "Don't Know",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Do Not Know"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Unknown"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Not Known"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Not Sure"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dont Know"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Unsure"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "944"
    }]
  },
  {
    "code" : "44100",
    "display" : "Sri Lankan nfd",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sri Lankan Nfd"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sri Lankan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Srilankan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sri Lanka"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sri Lanken"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ceylonese"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "441"
    }]
  },
  {
    "code" : "37135",
    "display" : "Papua New Guinean",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Papua New Guinean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Papua New Guinea"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Irian Jayan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Guinean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "PNG"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Papuan"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "371"
    }]
  },
  {
    "code" : "53100",
    "display" : "African nfd",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Black African"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "African Nfd"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Africa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Africian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "West African"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "East African"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Afro"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "African"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "12515",
    "display" : "Slovenian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Slovenian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Slovene"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "125"
    }]
  },
  {
    "code" : "12999",
    "display" : "European nec",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Greenlander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Friesian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Corsican"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dagestani"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "African European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Moldavian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Falkland Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Frankonian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Other European Nec"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Burgher"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Frisen"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Luxembourg"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kelper"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Liechtenstein"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European African"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Georgian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sardinian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Scandinavian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Basque"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Norman"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Azorean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Other European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Moldova"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Faroese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Frysland"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sami"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zambian European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Finno Ugric"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Frisian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Rhodesian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Nec"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "129"
    }]
  },
  {
    "code" : "431",
    "display" : "Indian",
    "property" : [{
      "code" : "parent",
      "valueCode" : "43"
    }]
  },
  {
    "code" : "12516",
    "display" : "Bosnian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Herzegovnian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bosnian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "125"
    }]
  },
  {
    "code" : "311",
    "display" : "Samoan",
    "property" : [{
      "code" : "parent",
      "valueCode" : "31"
    }]
  },
  {
    "code" : "52130",
    "display" : "Venezuelan",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Venezuelan"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "521"
    }]
  },
  {
    "code" : "12199",
    "display" : "British nec",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Orkney Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Gibraltarian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Gaelic"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Shetland Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "British Nec"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Orcadian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pictish"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "St Helenian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pict"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "121"
    }]
  },
  {
    "code" : "37137",
    "display" : "Pitcairn Islander",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pitcairn"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pitcairn Island"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pitcairnese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pitcairn Islander"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "371"
    }]
  },
  {
    "code" : "37138",
    "display" : "Rotuman",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Rotuma"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Rotamu"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Rotuman"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "371"
    }]
  },
  {
    "code" : "12513",
    "display" : "Macedonian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Macedonia"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Macedonian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "125"
    }]
  },
  {
    "code" : "12514",
    "display" : "Serbian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Serb"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Serbian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "125"
    }]
  },
  {
    "code" : "12511",
    "display" : "Croatian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hrvat"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Croat Croatian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Croatian European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Croat"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Croation"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kroatian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Croatia"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Croatian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "125"
    }]
  },
  {
    "code" : "12512",
    "display" : "Dalmatian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dalmatian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dali"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Daly"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dalmation"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Deli"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "125"
    }]
  },
  {
    "code" : "21111",
    "display" : "Māori",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Full Maori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ngati Porou"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Māori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ngati Tuwharetoa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tangatawhenua"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Waitaha"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Maori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tuhoe"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Descendant of a Maori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ngati Hineuru"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Maori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Moriori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tangata Whenua"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mori Ori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nga Puhi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Maori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tangata Whenua O Aotearoa"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Newzealand Maori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tainui"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ngapuhi"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Aotearoa Maori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ngai Tahu"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "211"
    }]
  },
  {
    "code" : "37122",
    "display" : "Hawaiian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hawaiian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "371"
    }]
  },
  {
    "code" : "37124",
    "display" : "Kiribati",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Gilbert Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kiribatese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kiribas"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kiribati"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ikiribati"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Gilbertese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kiribati Island"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "371"
    }]
  },
  {
    "code" : "44211",
    "display" : "Japanese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Okinawan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Japan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Japanese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Japanese"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Japanese"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "442"
    }]
  },
  {
    "code" : "441",
    "display" : "Sri Lankan",
    "property" : [{
      "code" : "parent",
      "valueCode" : "44"
    }]
  },
  {
    "code" : "321",
    "display" : "Cook Islands Maori",
    "property" : [{
      "code" : "parent",
      "valueCode" : "32"
    }]
  },
  {
    "code" : "442",
    "display" : "Japanese",
    "property" : [{
      "code" : "parent",
      "valueCode" : "44"
    }]
  },
  {
    "code" : "443",
    "display" : "Korean",
    "property" : [{
      "code" : "parent",
      "valueCode" : "44"
    }]
  },
  {
    "code" : "444",
    "display" : "Other Asian",
    "property" : [{
      "code" : "parent",
      "valueCode" : "44"
    }]
  },
  {
    "code" : "53114",
    "display" : "Kenyan",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kikuyu"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kikamba"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kenya"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kenyan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kimeru"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "53115",
    "display" : "Nigerian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Anaang"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Edo"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ibo"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "African Nigerian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nigeria"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Nigerian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "53113",
    "display" : "Jamaican",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Jamaican"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "53118",
    "display" : "Caribbean",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Rasta"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Virgin Islands"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Carribean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Afro Caribbean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "West Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "West Indies"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cayman Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bermudian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "St Vincents"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bahamian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Grenadian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Aruben"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Turks and Caicos Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Barbados"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Virgin Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Haitian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Vincentian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bajan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Barbadian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Caribbean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Black Caribbean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Trinidadian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "53119",
    "display" : "Somali",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Somalian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Somalia"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "African Somalian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Somali"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "53116",
    "display" : "African American",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Afro American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Black American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "African American"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "AfricanAmerican"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "43114",
    "display" : "Indian Tamil",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Dravidian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Indian Tamil"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tamil"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "431"
    }]
  },
  {
    "code" : "43115",
    "display" : "Punjabi",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Punjabi"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "431"
    }]
  },
  {
    "code" : "43116",
    "display" : "Sikh",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sikh"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sikhism"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "431"
    }]
  },
  {
    "code" : "95555",
    "display" : "Refused to Answer",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Refused to Answer"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Decline To Answer"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "None Of Your Business"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Refuse"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Object Very Seriously To This Question"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Object"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "RAZ"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Refuse To Answer"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Myob"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Object To Answering"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "RA"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "955"
    }]
  },
  {
    "code" : "37112",
    "display" : "Indigenous Australian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Aranda"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Australian Aborigine"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Indigenous Australian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Thursday Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Adnyamathanha"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Garama"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mari"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Flinders Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Meriam"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Torres Strait Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ngubin"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Aboriginal"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kuku-Yalanji"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Aborigine"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Australian Aboriginal"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Paman"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "371"
    }]
  },
  {
    "code" : "43111",
    "display" : "Bengali",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bengali"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bengalee"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Chakma"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "431"
    }]
  },
  {
    "code" : "43112",
    "display" : "Fijian Indian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Indo-Fijian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Indo Fijian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Fiji Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Fijian Indian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "431"
    }]
  },
  {
    "code" : "43117",
    "display" : "Anglo Indian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Angloindian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Anglo Indian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "431"
    }]
  },
  {
    "code" : "43118",
    "display" : "Malaysian Indian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Malaysian Indian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "431"
    }]
  },
  {
    "code" : "43119",
    "display" : "South African Indian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South African Indian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "431"
    }]
  },
  {
    "code" : "53121",
    "display" : "Ethiopian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Oromo"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "African Ethiopia"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tigrie"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tigrina"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tigray"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Afar"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ethiopian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tigrigna"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Amharic"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ethiopia"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Amhara"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "331",
    "display" : "Tongan",
    "property" : [{
      "code" : "parent",
      "valueCode" : "33"
    }]
  },
  {
    "code" : "53122",
    "display" : "Ghanaian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ghana"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Ghanaian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "211",
    "display" : "Māori",
    "property" : [{
      "code" : "parent",
      "valueCode" : "21"
    }]
  },
  {
    "code" : "53120",
    "display" : "Eritrean",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Eritrea"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Eritrean"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "32100",
    "display" : "Cook Islands Maori",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Rarotongan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Atiu Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cook Islands"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mauke Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mangaian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Aitutaki Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mangaia Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cook Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cook Islander Maori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Raro"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Raro Tongan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cook Island Maori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cook Island"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Cook Islands Maori"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Mitiaro Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pukapukan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Penrhyn Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Manihiki Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Palmerston Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Rakahanga Islander"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Pukapuka Islander"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "321"
    }]
  },
  {
    "code" : "53125",
    "display" : "Sudanese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sudanese"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "53126",
    "display" : "Zambian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zambian Coloured"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zambian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "53123",
    "display" : "Burundian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Burundian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "53124",
    "display" : "Congolese",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Congolese"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "53127",
    "display" : "Other Zimbabwean",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Other Zimbabwean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "African Zimbabwean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Coloured Zimbabwean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Zimbabwean Coloured"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "531"
    }]
  },
  {
    "code" : "12611",
    "display" : "Italian",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Italian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Itariano"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Italian European"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Itari"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Italy"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Roman"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "European Italian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Sicilian"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "126"
    }]
  },
  {
    "code" : "43100",
    "display" : "Indian nfd",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Indian Nfd"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Hindu"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Indian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "India"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "431"
    }]
  },
  {
    "code" : "44311",
    "display" : "Korean",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "North Korean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "NZ Korean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South Korea"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Republic Of Korea"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South Korean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Seoul"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Seoul Korea"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Korean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "New Zealand Korean"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Korea"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "443"
    }]
  },
  {
    "code" : "341",
    "display" : "Niuean",
    "property" : [{
      "code" : "parent",
      "valueCode" : "34"
    }]
  },
  {
    "code" : "100",
    "display" : "European nfd",
    "property" : [{
      "code" : "parent",
      "valueCode" : "10"
    }]
  },
  {
    "code" : "51199",
    "display" : "Middle Eastern nec",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tunisian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Omani"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Berber"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Libyan"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Bahraini"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Middle Eastern Nec"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Libya"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tunisia"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Kuwaiti"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Yemeni"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Azerbaijani"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "511"
    }]
  },
  {
    "code" : "12500",
    "display" : "South Slav nfd",
    "designation" : [{
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Yugoslavian"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Jugoslav"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Yugoslav"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "Tarara"
    },
    {
      "language" : "en-NZ",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009"
      },
      "value" : "South Slav Nfd"
    }],
    "property" : [{
      "code" : "parent",
      "valueCode" : "125"
    }]
  }]
}

```
